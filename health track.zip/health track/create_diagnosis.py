import sqlite3

# Connect to your database
conn = sqlite3.connect('medtrack.db')
cursor = conn.cursor()

# List all table names
cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
tables = cursor.fetchall()

print("\n✅ Tables in your medtrack.db:")
for table in tables:
    print(table)

conn.close()